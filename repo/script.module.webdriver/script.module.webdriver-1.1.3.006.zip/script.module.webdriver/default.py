# -*- coding: utf-8 -*-

from resources.lib.wds import WDS

if (__name__ == "__main__"):
    WDS()

