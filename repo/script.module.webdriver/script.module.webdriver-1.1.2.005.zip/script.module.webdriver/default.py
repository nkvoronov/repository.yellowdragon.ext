# -*- coding: utf-8 -*-

from resources.lib.webdriver_select import WDS

if (__name__ == "__main__"):
    WDS()

